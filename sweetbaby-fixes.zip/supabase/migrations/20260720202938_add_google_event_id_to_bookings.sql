-- Track the Google Calendar event created for each studio booking, so it can
-- be updated/cancelled later if the booking changes.
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS google_event_id TEXT;
