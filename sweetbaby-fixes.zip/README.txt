קבצים מתוקנים/חדשים לפרויקט Sweetbaby - להעלות כל קובץ למקום המקביל ב-GitHub:

1. src/lib/orders.functions.ts        (מעודכן - תיקון שגיאת UUID בהזמנת אביזרים)
2. src/routes/checkout.tsx            (מעודכן - אותו תיקון, צד לקוח)
3. src/lib/bookings.functions.ts      (מעודכן - סנכרון אוטומטי ל-Google Calendar)
4. src/integrations/google/calendar.server.ts  (חדש - קובץ עזר לחיבור ל-Google Calendar)
5. src/routes/studio-rental.tsx       (מעודכן - הוחלף ה-iframe בכפתור לדף /booking)
6. supabase/migrations/20260720202938_add_google_event_id_to_bookings.sql (חדש - עמודה במסד הנתונים)

חשוב: כדי שסנכרון היומן יעבוד בפועל, צריך גם להוסיף 3 משתני סביבה ב-Lovable:
GOOGLE_CALENDAR_CLIENT_ID, GOOGLE_CALENDAR_CLIENT_SECRET, GOOGLE_CALENDAR_REFRESH_TOKEN
(ההוראות המלאות להשגתם נשלחו בצ'אט).
